#! /bin/bash

##05/03/2013
##CuReSim Wrapper for Galaxy
##@PEGASE-Biosciences

output_sim=$1
log_sim=$2
input=$3
number_reads=$4
reads_size=$5
full=$6
standard_deviation=$7
random_rate=$8
deletion_rate=$9
insertion_rate=${10}
substitution_rate=${11}
uniform_indels=${12}
uniform_subs=${13}
encoding=${14}
skip=${15}


echo $full


path=`dirname $0`;
number=$RANDOM;

mkdir $path/tmp/$number
cd $path/tmp/$number


if [ $full == 'no' ]
then
	standard_deviation="20.0"
	random_rate="0"
	deletion_rate="0.01"
	insertion_rate="0.005"
	substitution_rate="0.005"
	uniform_indels="homopolymers"
	uniform_subs="exponential"
	encoding="5"
	
fi
echo $skip
if [ $full == 'yes' ]
then
	if [ $skip == '0' ]
	then
		skip=""
	else
		if [ $skip == '1' ]
		then
			skip="-skip"
		fi
	fi
fi

cp $input $path/tmp/$number/input.fasta

echo "java -jar CuReSim.jar
  -o $output_sim
  -f $input
  -n $number_reads
  -m $reads_size
  -sd $standard_deviation
  -r $random_rate
  -d $deletion_rate
  -i $insertion_rate
  -s $substitution_rate
  -ui $uniform_indels
  -us $uniform_subs
  -q $encoding
  $skip"


java -jar $path/CuReSim.jar -f $path/tmp/$number/input.fasta -n $number_reads -m $reads_size -sd $standard_deviation -r $random_rate -d $deletion_rate -i $insertion_rate -s $substitution_rate -ui $uniform_indels -us $uniform_subs -q $encoding $skip

mv $path/tmp/$number/output.fastq $output_sim
mv $path/tmp/$number/log.txt $log_sim


