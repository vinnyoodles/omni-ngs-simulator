{- Extremely simple tool to filter reads by length -}

module GelFilter where

import System.Environment (getArgs)
import System.IO

import Bio.Core.Sequence
import Bio.Sequence.Fasta

main :: IO ()
main = do
  [min,max] <- map read `fmap` getArgs
  hWriteFasta stdout =<< filter (\x -> seqlength x>=(Offset min) && seqlength x<= (Offset max)) `fmap` hReadFasta stdin
  