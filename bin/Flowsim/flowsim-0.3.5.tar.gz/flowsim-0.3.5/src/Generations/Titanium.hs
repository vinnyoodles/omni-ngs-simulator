module Generations.Titanium where

import Generations.GenBase
import qualified Data.ByteString.Char8 as BC

titanium :: Generation
titanium = Gen
       { name     = "Titanium"
       , qcall     = qual_exact_fixed
       , models   = [\h -> let h' = fromIntegral h 
                           in if h == 0 then LogNormal (negate 2.5) 0.2 else Normal h' (0.04+0.05*h')]
       , degrade  = Normal 0.001 0.001
       , disc_filters = [discard_key "TCAG", discard_empty,discard_dots 0.05,discard_mixed,discard_length 186]
       , trim_filters = [trim_sigint, trim_qual20 10] -- find_primer
       , f_key        = "TCAG"
       , f_len        = 800 -- :: Int16
       , f_cycle      = "TACG"
       , adapter      = "ctgagactgccaaggcacacagggggatagg"
       }

{- seen:
   ggcgggcgatgtctcgtctgagcgggctggc aaggc                <- in transcriptome seq.
                      ctgagactgcc  aaggcacacagggggatagg <- sea bass and cod?
                      agtcgtggaggc aaggcacacaggg--atagg <- "rapid" kit

From: http://seqanswers.com/forums/showthread.php?t=2698
                   TCGTATAACTTCGTATAATGTATGCTATACGAAGTTATTACG  
                   GTTGGAACCGAAAGGGTTTGAATTCAAACCCTTTCGGTTCCAAC

Todo: check MIRA and sffToWhatever from Celera.

-}