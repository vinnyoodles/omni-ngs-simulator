module Version where

version :: String
version = " v0.3.5, copyright 2010-2012 Ketil Malde"
