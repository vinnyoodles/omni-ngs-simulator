This is an XML wrapper that provides a GUI for Grinder in Galaxy (http://galaxy.psu.edu/).

Place these files in your Galaxy directory. More information at http://wiki.g2.bx.psu.edu/FrontPage.

Note: The Grinder wrapper uses Galaxy builtin datasets located in the 'all_fasta' data table.
